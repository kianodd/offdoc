### SDK

The `@nestjs/observe` SDK is what gets your application's requests, jobs, errors, logs, and traces into your [NestJS Observe](https://www.observe.nestjs.com/ 'NestJS Observe') dashboard. It hooks into Nest's own request lifecycle - controllers, interceptors, resolvers, queue consumers - rather than bolting a generic Node.js agent onto the process, so most of what shows up in the dashboard needs no manual span wiring.

> info **Hint** Not sure it is worth the setup yet? The [live demo](https://www.observe-demo.nestjs.com/dashboard 'NestJS Observe live demo') shows what this instrumentation produces - traces, waterfalls, errors and jobs from a busy service - without installing anything.

#### Installation

There are two ways to set up the SDK: one command that does it for you, or the same steps by hand.

**With one command.** Run the following in your project's directory:

```bash
$ npx @nestjs/observe link
```

The command prints an eight-letter code. Type it at [observe.nestjs.com/link](https://www.observe.nestjs.com/link 'Link a project to NestJS Observe'), signing up first if you don't have an account, and approve. The command then writes the project's key pair into `.env` as `OBSERVE_APP_KEY` and `OBSERVE_APP_SECRET`, git-ignores `.env`, and adds `--env-file .env` to every script that runs `nest start` (`start`, `start:dev`, and `start:debug` in a `nest new` project).

If the application doesn't use the SDK yet, the command also installs `@nestjs/observe` with your package manager and makes the three edits from the [Quick start](#quick-start) below for you. It tells you so before you approve. See [Linking from the terminal](#linking-from-the-terminal) for exactly what it changes.

> warning **Warning** The SDK requires `@nestjs/core` v11.1.4 or later (it relies on the `instrument` application option introduced in that release), and `@nestjs/graphql` v13.4.4 or later if your application uses GraphQL. Earlier versions lack the hooks the SDK needs.

**By hand.** Install the SDK:

```bash
$ npm i @nestjs/observe
```

Then make the three edits from the [Quick start](#quick-start) below, generate an API key on your project's **API Keys** page (see [First project](/observability/overview#first-project)), and set the key pair as `OBSERVE_APP_KEY` and `OBSERVE_APP_SECRET`. This is also the way to go wherever the command leaves the wiring to you.

#### Quick start

The integration takes three steps. First, call `createObserveModule()` once, typically in `app.module.ts` or another root-level file. It returns a matched pair - a Nest module and an `instrument` hook - bound to the same configuration:

```typescript
@@filename(app.module)
import { Module } from '@nestjs/common';
import { createObserveModule } from '@nestjs/observe';
import { AppController } from './app.controller.js';
import { AppService } from './app.service.js';

export const { ObserveModule, ObserveInstrument } = createObserveModule();

@Module({
  imports: [
    ObserveModule.forRoot({
      appKey: process.env.OBSERVE_APP_KEY!,
      appSecret: process.env.OBSERVE_APP_SECRET!,
      serviceId: 'cats-app',
    }),
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
```

Second, import `ObserveModule.forRoot()` into your root module with at least a `serviceId` (shown above). Third, pass `ObserveInstrument` to `NestFactory.create()` so the SDK attaches to the application before it starts handling traffic:

```typescript
@@filename(main)
import { NestFactory } from '@nestjs/core';
import { AppModule, ObserveInstrument } from './app.module.js';

async function bootstrap() {
  const app = await NestFactory.create(AppModule, {
    instrument: ObserveInstrument,
  });
  await app.listen(process.env.PORT ?? 3000);
}
await bootstrap();
```

> warning **Fastify** With `FastifyAdapter` (or any explicit adapter), the adapter takes the second argument, so the application options - and therefore `instrument` - move to the **third**:
>
> ```typescript
> const app = await NestFactory.create<NestFastifyApplication>(
>   AppModule,
>   new FastifyAdapter(),
>   { instrument: ObserveInstrument },
> );
> ```
>
> Passing the options object as the second argument alongside an adapter silently drops them, and the SDK never attaches.

That completes the integration. Once the application receives traffic, requests, errors, and traces appear in your project's dashboard within moments, with no exporter to configure and no schema to design. The same `instrument` option is accepted by `NestFactory.createMicroservice()` and `NestFactory.createApplicationContext()`, so workers and standalone applications are instrumented the same way.

> info **Hint** `createObserveModule()` itself takes an options object that controls how trace ids are generated, how error source context is captured, and which providers are instrumented - see [Trace correlation](#trace-correlation) and [Error source context](#error-source-context) below. Everything else is configured through `ObserveModule.forRoot()`.

#### Configuring the module

Beyond the credentials in the quick start, these options decide how the SDK identifies your application, where it sends what it records, and how much it tells you about itself.

##### Authenticating and identifying the application

```typescript
ObserveModule.forRoot({
  appKey: process.env.OBSERVE_APP_KEY!,
  appSecret: process.env.OBSERVE_APP_SECRET!,
  serviceId: 'cats-app',
});
```

| Option           | Type     | Default  | Description                                                                                                                                                                                                |
| ---------------- | -------- | -------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `appKey`         | `string` | required | Written into `.env` as `OBSERVE_APP_KEY` by `npx @nestjs/observe link`, or generated from your project's **API Keys** page - see [First project](/observability/overview#first-project). Keep it out of source control. |
| `appSecret`      | `string` | required | Issued alongside `appKey`, the same way, and written as `OBSERVE_APP_SECRET`. Keep it out of source control.                                                                                               |
| `serviceId`      | `string` | required | Identifies this application in your dashboard. If you run multiple instances of the same service, use a value unique per instance (hostname, container id) to tell them apart in the Profiler. |
| `serviceVersion` | `string \| false` | inferred | Identifies the deployment - a semantic version, a commit hash, or any other identifier, at most 50 characters. When it isn't set, the SDK infers it at startup (see below); `false` reports none. |

Every request and job records the release that served it, which is what powers the **Releases** view: each version compared against the one before it, and a [verdict](/observability/dashboard#releases-and-their-verdicts) on what it changed. You usually don't need to set `serviceVersion`. When it isn't set, the SDK infers the release when the application starts, from the first of these that has one:

1. **`OBSERVE_SERVICE_VERSION`** in the environment, for a deploy that wants to be explicit without touching code.
2. **The commit your platform or CI exposes at runtime**: Vercel, Render, Railway, Heroku (with dyno metadata), Coolify, and Dokku, or GitHub Actions, GitLab CI, Bitbucket Pipelines, CircleCI, Buildkite, Azure Pipelines, and AWS CodeBuild for an application a CI job boots. `GIT_COMMIT_SHA`, `GIT_COMMIT`, `GIT_SHA`, `COMMIT_SHA`, and `SOURCE_VERSION` are read too.
3. **The commit checked out where the process runs**, read from the repository's `.git`.
4. **The revision a container platform names each deploy by**: Cloud Run's `K_REVISION`, Azure Container Apps' `CONTAINER_APP_REVISION`.

A container image built by your own pipeline usually carries none of these, since the build excludes `.git` and CI variables don't survive into the image. Hand it the commit at build time:

```bash
$ docker build --build-arg GIT_SHA=$(git rev-parse HEAD) .
```

with `ARG GIT_SHA` and `ENV OBSERVE_SERVICE_VERSION=$GIT_SHA` in the Dockerfile. A `serviceVersion` you pass yourself wins over all of the above. An inferred commit is reported in full, as `git rev-parse HEAD` prints it, and the dashboard shortens it for display; that full form is also what to pass as `fixedInVersion` when resolving an issue.

<figure><img src="https://www.observe.nestjs.com/docs/sdk/deployments.webp" alt="Releases" /></figure>

##### Linking from the terminal

`npx @nestjs/observe link` puts a key pair on a developer's machine without copying a secret out of the browser, and sets the SDK up in an application that doesn't use it yet. Run it in the project's directory (the one with `package.json`), or point it there with `--cwd <dir>`:

1. It prints an eight-letter code, such as `BCDF-GHJK`, and opens [observe.nestjs.com/link](https://www.observe.nestjs.com/link 'Link a project to NestJS Observe') in your browser. With `--no-browser`, in CI, or without a terminal, it only prints the address. The code expires after 15 minutes. If the application doesn't use the SDK yet, the command also says, below the code, that it will install and wire it once you approve.
2. Type the code on that page. If you don't have an account yet, you sign up first; if you're signed out, you sign in. Either way, you come back to the code afterwards.
3. Check the request: the page shows the hostname of the machine and the package name the command sent. Then choose where the key goes. The page proposes your newest project, and in it the application named after your package, or a new application if there isn't one yet. You can change both, including to a new project.
4. Approve. The dashboard issues a new API key for that application, and the command writes it into the project.

In every project, the command changes up to three files:

- **`.env`** receives `OBSERVE_APP_KEY` and `OBSERVE_APP_SECRET`, single-quoted, replacing an earlier pair and leaving every other line as it was. A new `.env` is created readable only by you. The quotes are deliberate: a key or secret can contain `$` and `&`, which `dotenv-expand` (or `ConfigModule` with `expandVariables`) would rewrite, and at which a shell sourcing the file would stop.
- **`.gitignore`** gets a `.env` entry, unless the file is already ignored (as it is in a project generated by `nest new`).
- **`package.json`**: every script whose command begins with `nest start` gets `--env-file .env`: `start`, `start:dev`, and `start:debug` in a project generated by `nest new`, and a monorepo's per-application scripts as well. Scripts that already pass an env file are left alone, and so is `start:prod` (`node dist/main`). A `start` or `start:dev` script that starts the application some other way is left alone too, but the command names it, so you can load `.env` there yourself (for example, with `node --env-file=.env`).

In an application that doesn't use the SDK yet (no source file imports `@nestjs/observe`), the command also sets the SDK up, the way `nest new` does:

- **The SDK** is installed at the command's own version (`@nestjs/observe@^0.3.16` from 0.3.16). The command uses the package manager that the project's lockfile belongs to (pnpm, Yarn, Bun, or npm), looking up to the repository's root, so that a package in a workspace finds the root's lockfile. Without a lockfile, it uses the one named by the `packageManager` field in `package.json`, and npm otherwise. An `@nestjs/observe` that is already installed but older than the command is upgraded the same way. In that case, run `npx @nestjs/observe@latest link`, because plain `npx` runs the version installed in the project.
- **The root module**, the one `main.ts` passes to `NestFactory.create()` (found by following its import), gets the `createObserveModule()` call, and `ObserveModule.forRoot()` as the first entry of its `imports`. The options read the key pair from `OBSERVE_APP_KEY` and `OBSERVE_APP_SECRET`, and set `serviceId` to the name of the application you approved, lower-cased, with spaces turned into dashes and any other punctuation dropped (`Cats API` becomes `cats-api`).
- **`main.ts`** passes `instrument: ObserveInstrument` to `NestFactory.create()`, inside its options object, or as a new options argument if there is none.

The edits follow each file's quotes, semicolons, and indentation, and either both files change or neither does. The command lists them, so you can review them with `git diff`.

In some projects, the command leaves the wiring to you and prints why; the [Quick start](#quick-start) shows the edits to make. It does so in a workspace with several applications (the key belongs to one of them), in a JavaScript project, and wherever it can't edit the code safely, for example when `main.ts` imports the root module through a path alias rather than a relative path, when `imports` isn't a plain array, or when an `instrument` option is already passed. If the installation fails, the command prints the install command for you to run yourself, and leaves the wiring to you as well.

Before it asks for a code, the command turns away a project that it would have to install the SDK in but that has no `@nestjs/core`, or runs a NestJS version older than 11.

Nothing is written until the key arrives, so a denied, expired, or interrupted link leaves the project unchanged.

> warning **Warning** Approve only a code you started yourself, and only when it matches your terminal. The code is typed rather than carried in a URL so that nobody can send you a link that approves a key for them.

The key appears on the project's **API Keys** page like any other, named `CLI` followed by the time it was issued, and expires after a year; run the command again for a new one. `.env` stays on the machine that ran the command, so each teammate (or each additional machine) runs `npx @nestjs/observe link` as well and gets a key of its own for the same application.

##### Reading the key pair from the environment

When `appKey` or `appSecret` is unset or empty, or still holds the placeholder that `nest new` generates (`'YOUR_APP_KEY'` and `'YOUR_APP_SECRET'`), `ObserveModule` reads `OBSERVE_APP_KEY` or `OBSERVE_APP_SECRET` from the environment instead. This is what lets a project generated with Observe report once it's linked, without any change to `AppModule`. A value you pass yourself always wins, and the same fallback applies to the options that `forRootAsync()` resolves.

The variables are read when the options are resolved (for `forRoot()`, when the `AppModule` file is imported), so they must already be in `process.env` at that point. The `--env-file` flag loads them before any module runs.

In production, set `OBSERVE_APP_KEY` and `OBSERVE_APP_SECRET` in the environment (your platform's secrets or environment settings) rather than shipping `.env`. A project generated by `nest new` runs `node dist/main` for `start:prod`, which doesn't load `.env` anyway, and `nest start` skips an `--env-file` that doesn't exist, so a fresh clone or a CI run without `.env` still starts. Give production a key of its own from the project's **API Keys** page, so revoking a development key never stops it from reporting.

> info **Hint** The `link` command and the environment fallback require `@nestjs/observe` 0.3.15 or later. Installing and wiring the SDK into an application that doesn't use it yet requires 0.3.16 or later.

##### Turning the SDK off outside production

To keep an environment from reporting - local development, a CI run - keep `ObserveModule` imported and switch it off with `enabled`, rather than passing fake credentials, which are sent and refused:

```typescript
ObserveModule.forRoot({
  enabled: process.env.NODE_ENV === 'production',
  appKey: process.env.OBSERVE_APP_KEY ?? '',
  appSecret: process.env.OBSERVE_APP_SECRET ?? '',
  serviceId: 'cats-app',
});
```

`enabled: false` records and sends nothing - no traces, runtime metrics, or logs, and no request to any collector - and needs no credentials. The module stays in place, so `TracerService` can still be injected and calling it is harmless. Leaving the credentials unset also sends nothing, but logs a warning at every start, since in production that usually means the environment variables never reached the process. `enabled` requires `@nestjs/observe` 0.3.13 or later.

##### Asynchronous configuration

When the credentials come from a configuration provider rather than directly from `process.env`, use `forRootAsync()`. It accepts the same `useFactory`/`inject`, `useClass`, and `useExisting` shapes as every other Nest dynamic module (a class implements `ObserveOptionsFactory` with a `createObserveOptions()` method), plus `extraProviders` and `global`:

```typescript
@@filename(app.module)
ObserveModule.forRootAsync({
  imports: [ConfigModule],
  inject: [ConfigService],
  useFactory: (config: ConfigService) => ({
    appKey: config.getOrThrow('OBSERVE_APP_KEY'),
    appSecret: config.getOrThrow('OBSERVE_APP_SECRET'),
    serviceId: config.get('SERVICE_ID', 'cats-app'),
    serviceVersion: config.get('GIT_SHA'),
  }),
});
```

##### Collector endpoint

```typescript
ObserveModule.forRoot({
  // ...
  endpoint: 'https://observe-api.nestjs.com',
});
```

`endpoint` (default `'https://observe-api.nestjs.com'`) is the base URL of the collector. Telemetry and profiles share it, so the two can never point at different places. To override it without touching the config, set the `OBSERVE_ENDPOINT` environment variable. NestJS Observe is a hosted service and `observe-api.nestjs.com` is the only collector it runs; change the endpoint when your traffic has to leave through a forwarding proxy, or to point a test environment at a stub that accepts the batches.

##### Debugging the SDK itself

```typescript
ObserveModule.forRoot({
  // ...
  debug: true,
});
```

`debug` (default `false`) logs additional diagnostic information from the SDK to the console. Use it while getting instrumentation working, and turn it off in production.

##### Shutdown

When the application closes - `app.close()`, or a `SIGTERM` once `app.enableShutdownHooks()` has been called - the SDK sends what it still holds before it stops: the requests and jobs that finished since the last batch, their errors, the log lines buffered before shutdown began, and a last runtime sample. It waits at most `shutdownFlushTimeout` (default `2000` ms) for the collector, then lets the application exit; `0` skips the final send.

Two things decide what makes it in:

- **Signals.** Nest runs shutdown hooks on `SIGTERM` only if the application called `app.enableShutdownHooks()` at bootstrap. Without it, a deploy or a scale-in ends the process at once, and the last few seconds of telemetry are lost.
- **Module order.** Global modules shut down in reverse order of import. A job still running at shutdown is reported only if `ObserveModule` comes before `BullModule`, and before any module that registers a queue, in your root module's `imports`.

In test suites that boot the application with real credentials, set `shutdownFlushTimeout: 0`, so every `app.close()` doesn't send that test's requests to your project or wait on a collector the test environment can't reach. The final send requires `@nestjs/observe` 0.3.10 or later.

#### Automatic instrumentation

Everything in this section is recorded without any code of your own; installing the SDK is enough. The options only narrow it or switch it off.

##### Database queries and outbound HTTP

Since `@nestjs/observe` 0.3.0, database queries and outbound requests appear as spans with no configuration, nested under the method that made them. A slow repository call shows _which_ statement it was waiting on.

<figure><img src="https://www.observe.nestjs.com/docs/telemetry/sql.webp" alt="A query opened in the waterfall" /></figure>

Databases are instrumented at the driver rather than the ORM: `pg`, `mysql2`, `mssql`, and `mongodb` are detected if your application already depends on them, which covers TypeORM, MikroORM, Drizzle, Mongoose, Knex, Sequelize, and Prisma's driver adapters without naming any of them. SQL Server is the exception: `mssql` is what TypeORM and Prisma's SQL Server adapter run on, but Knex, Sequelize, and MikroORM talk to SQL Server through `tedious` directly, which isn't covered yet (nor is `mssql/msnodesqlv8`). ORMs that ship their own nested copy of a driver (MikroORM and Mongoose do, whenever versions disagree) are handled too. The driver's own housekeeping (connection handshakes, authentication, pings) is not recorded. A query span is labeled with its verb and table (`SELECT users`) and carries the statement with **every literal removed** - strings, numbers, `IN (...)` lists, and comments are replaced before the span leaves the process, and bound parameters are never read at all. Repeated queries under one parent fold into a single node with a count, so an N+1 reads as `SELECT order_items ×47` rather than 47 rows.

Other clients, Redis and Kafka among them, aren't instrumented at the library. A Nest application almost always registers them as providers, though - an `ioredis` client from a factory, a `ClientKafka` from `ClientsModule` - and the SDK records every provider's method calls: each call on the client is a span under the method that made it, and one that returns a promise, as `ioredis` commands do, is timed until it settles. A client created and called outside dependency injection isn't recorded.

Outbound HTTP is read from Node's own diagnostics channels, so `fetch`, `undici`, and everything built on `node:http` (axios, got, most SDKs) are covered with nothing patched. The span is labeled `GET api.example.com` and carries the URL with sensitive query parameters masked. The SDK also sends the current trace id as `x-request-id`, which makes [HTTP-to-HTTP tracing](/observability/distributed-tracing#http-to-http) automatic. With the [`openTelemetry`](/observability/opentelemetry#running-beside-opentelemetry) option on, it sends a W3C `traceparent` as well: `http.traceContext: false` keeps that header off, and `propagateTraceId` decides where both headers go.

```typescript
ObserveModule.forRoot({
  // ...
  outgoing: {
    database: true,
    http: {
      ignore: (url) => url.startsWith('https://internal-metrics.'),
      // Only forward the trace id to your own services
      propagateTraceId: (url) => url.includes('.svc.cluster.local'),
    },
  },
});
```

Set `outgoing: false` to switch all of it off, or `database: false` / `http: false` individually.

> info **Hint** These spans are **not billed**. They are detail about a method span you already sent, so they don't count toward your Observability Events or your rate cap. A request that runs ten queries costs the same as before.

##### Model calls

Since `@nestjs/observe` 0.3.20, a `fetch` to a model provider also records what the call used on its outbound span: the model, the input, output, and cached input tokens the provider's response states, and, for a stream, the time to its first event. OpenAI, Azure OpenAI, Anthropic, Google Gemini and Vertex AI, Amazon Bedrock, Mistral, Groq, OpenRouter, Together AI, DeepSeek, xAI, Cohere, and Perplexity are recognized by host, so the official SDKs, the Vercel AI SDK, and LangChain are all covered without being named.

- **Read as the response passes through.** The SDK reads the response at the pace your code does, streams included, and hands it on unchanged. A stream your code cancels is cancelled at the provider too.
- **Prompts and completions are never sent.** Only the model and the token counts leave the process.
- **`fetch` only.** A call made through `node:http` - axios, or the AWS SDK's default client for Bedrock - keeps its ordinary outbound span without the model or tokens.

A gateway in front of the providers (LiteLLM, Portkey, your own proxy) or a self-hosted model with an OpenAI-compatible API is added by host, and its calls are tagged with the provider `custom`. `outgoing: {{ '{' }} llm: false {{ '}' }}` stops reading model calls while keeping their plain spans:

```typescript
ObserveModule.forRoot({
  // ...
  outgoing: {
    llm: { hosts: ['llm-gateway.internal:4000'] },
  },
});
```

A [production rule](/observability/production-rules) can bound how many model calls a request makes.

##### WebSocket gateways

Messages handled by `@SubscribeMessage()` are reported as requests with the `ws` protocol and an operation id of `GatewayClass:pattern`, on any platform adapter. The `ws` option block takes the same `ignore`, `tags`, `setAttributes`, and `getUserId` hooks as the other transports; each receives `{{ '{' }} gateway, pattern, client, data {{ '}' }}`. Connections and disconnections are not operations and are not reported.

##### Queues

`@nestjs/bullmq` and the original `@nestjs/bull` are both instrumented: every processor run is reported as a job, with its queue wait, attempt number, and outcome. A job added from inside a traced operation inherits that operation's trace id - see [Distributed tracing](/observability/distributed-tracing#queue-jobs-bullmq-and-bull).

##### Runtime metrics and profiling

```typescript
ObserveModule.forRoot({
  // ...
  runtimeMetrics: true,
  runtimeMetricsInterval: 60000,
});
```

`runtimeMetrics` (default `true`) samples memory, CPU, garbage collection, and event loop latency on an interval (`runtimeMetricsInterval`, default `60000` ms) and feeds the **Profiler**. The same samples double as the application's heartbeat: a **Telemetry silence** alert fires when they stop arriving, which gives you lightweight uptime monitoring without an external probe.

#### Errors and failed requests

An error that escapes a controller, resolver, or job is captured automatically. These options decide what comes with it: the source code around the failing frame, and the headers and body of the request that failed.

##### Error source context

Errors that propagate out of a controller, resolver, job, or span are captured automatically. When `sourceContext` is enabled (the default), the SDK also reads the source lines around each in-app stack frame of a captured error and attaches them. This lets the dashboard show the failing code alongside the stack trace, even for a production failure on a build you don't have checked out.

```typescript
@@filename(app.module)
export const { ObserveModule, ObserveInstrument } = createObserveModule({
  sourceContext: {
    linesOfContext: 5,
    maxFrames: 5,
    sourceMaps: false,
  },
});
```

This is an option of `createObserveModule()`, not `forRoot()`. Set `sourceContext: false` to disable it, or pass an object to tune the defaults:

| Option           | Type      | Default | Description                                                                                                                                                                                                                                                                                                                                                                     |
| ---------------- | --------- | ------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `linesOfContext` | `number`  | `5`     | Lines read on either side of the frame's line.                                                                                                                                                                                                                                                                                                                                  |
| `maxFrames`      | `number`  | `5`     | How many in-app frames, counted from the top of the stack, get source attached. Bounds the payload on deep stacks.                                                                                                                                                                                                                                                             |
| `sourceMaps`     | `boolean` | `false` | Resolves compiled frames back through source maps before reading source. Only needed if the process runs compiled output _without_ Node's own source map support (`--enable-source-maps` or `process.setSourceMapsEnabled(true)`); with that on, frames already carry original positions and this is redundant. Costs a map parse per compiled file on first touch, cached after. |

> warning **Warning** Enabling this ships fragments of your application's source code (usually a few lines around the error) to your dashboard, where they are stored alongside the error. Frames inside `node_modules` and Node internals are never read, only application source. Turn it off if shipping any source is not acceptable for your codebase.

<figure><img src="https://www.observe.nestjs.com/docs/telemetry/error-with-source.webp" alt="Error card with source context" /></figure>

##### Capturing failed and slow requests

When an HTTP request **fails**, the SDK records a small, fixed allow-list of its headers alongside it - `user-agent`, `content-type`, `content-length`, `accept`, `host`, `origin` and `referer`. None of these authenticate or identify the caller. If you set `slowerThanMs`, requests that ran at least that long are captured the same way, failed or not. An ordinary request records nothing. Request bodies are **off** by default; turn them on explicitly if you want them:

```typescript
ObserveModule.forRoot({
  // ...
  http: {
    capture: {
      headers: ['user-agent', 'x-tenant-id'],
      body: { maxBytes: 4096 }, // default 2048, at most 16384
      slowerThanMs: 2000,
    },
  },
});
```

Everything captured passes through [`redaction`](/observability/sdk#logs) before it leaves the process: sensitive keys (`password`, `token`, `authorization`, ...) are masked by name inside the body, and naming a sensitive header records `[REDACTED]` instead of its value. `capture: false` records nothing. The capture is shown on the request's detail page as a **Request** card.

#### Logs and trace correlation

Every execution gets a trace id. These options decide how your log lines relate to it: forwarded to the dashboard, or only stamped with the id so your own log stack can link to the trace.

##### Logs

```typescript
ObserveModule.forRoot({
  // ...
  forwardLogs: true,
  redaction: {
    enabled: true,
    keys: ['internalToken'],
    patterns: [/acct_[a-z0-9]{16}/gi],
  },
});
```

`forwardLogs` (default `false`) sends your application's log lines (anything written through Nest's `Logger`) to the dashboard, correlated to the trace that was active when each line was written. On an execution page, every line is placed on the trace's clock next to the span that was in flight when it was written. Log forwarding is available on Pro and above.

Forwarding logs moves them onto infrastructure you don't control, so redaction is on by default. The same redaction also scrubs the message and stack of every captured error and any captured request data, whether or not `forwardLogs` is on:

| `redaction` field    | Type       | Default        | Description                                                                                                                                                                                                                                                              |
| -------------------- | ---------- | -------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `enabled`            | `boolean`  | `true`         | Whether anything is scrubbed at all.                                                                                                                                                                                                                                     |
| `useDefaultPatterns` | `boolean`  | `true`         | Applies the built-in patterns: bearer tokens, JWTs, AWS key ids, PEM private keys, passwords in URLs (`scheme://user:password@host`), `key=value` secrets, and Luhn-valid card numbers. Disable only if you're replacing them wholesale with your own `patterns`; there's no supported case for forwarding logs unredacted.  |
| `patterns`           | `RegExp[]` | -              | Extra patterns to mask, for secrets shaped in a way only your codebase knows (internal token prefixes, customer identifiers). Always applied as if global, so a match is never limited to the first occurrence in a line.                                                |
| `keys`               | `string[]` | -              | Extra keys whose values are masked outright (in log attributes, captured headers and bodies, and URL query strings), on top of the built-in list. Compared case-insensitively and ignoring `-`/`_`, so `apiKey`, `api_key`, and `API-KEY` are one entry.                                                                               |
| `replacement`        | `string`   | `'[REDACTED]'` | Text substituted for anything matched.                                                                                                                                                                                                                                   |

> info **Hint** Even with `forwardLogs` off, the SDK augments `ConsoleLogger` so every line written inside a traced execution carries its trace id (`attachTraceIdToLogs`, see [Trace correlation](#trace-correlation)). That lets you correlate your own log aggregator with traces in the dashboard without shipping the log content anywhere.

##### Trace correlation

These are also options of `createObserveModule()`. They shape how requests get a trace id and how that id shows up in your own logs:

```typescript
@@filename(app.module)
import { randomUUID } from 'node:crypto';

export const { ObserveModule, ObserveInstrument } = createObserveModule({
  traceIdKey: 'traceId',
  traceIdGenerator: (req: any) => req.headers['x-request-id'] ?? randomUUID(),
  attachTraceIdToLogs: true,
});
```

| Option                | Type                       | Default                                                       | Description                                                                                                                         |
| --------------------- | -------------------------- | ------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------- |
| `traceIdKey`          | `string`                   | `'traceId'`                                                   | The key used to store the trace id in the request context, for later retrieval through `TracerService`.                            |
| `traceIdGenerator`    | `(req: unknown) => string` | Adopts a well-formed `x-request-id` (HTTP header, or microservice packet metadata) if present, else a UUID v7 | Generates the trace id per request. Called with the request object for HTTP; for other protocols it receives the transport context. |
| `attachTraceIdToLogs` | `boolean`                  | `true`                                                        | Augments `ConsoleLogger` to include the trace id in log messages, so logs can be correlated with traces even without `forwardLogs`. In the default text format the id ends the line, after the message (`   Trace ID: <id>`); with [JSON logging](/application/logger#json-logging) it is a `traceId` field. Lines written outside a traced execution are unchanged. |

Because the default generator adopts an incoming `x-request-id`, a chain of HTTP services already shares one trace with no extra configuration. Services instrumented with OpenTelemetry pass the trace on in `traceparent` instead, which the `openTelemetry` option of `forRoot()` reads and sends - see [Running beside OpenTelemetry](/observability/opentelemetry#running-beside-opentelemetry). The same applies to the microservice transports: TCP and Redis on `@nestjs/microservices` 12.0.4 or later, and NATS, Kafka, RabbitMQ, MQTT 5, and gRPC on 12.3.3 or later. Propagating across earlier versions and GraphQL takes a few lines - see [Distributed tracing](/observability/distributed-tracing).

#### Shaping what is recorded

These options enrich what the SDK records (who a request was for, what it concerned) and keep out what you don't need.

##### Associating users with telemetry

`getUserId` reads the incoming request and returns whatever identifier your system uses for a person: a user id, an account id, or a tenant-scoped id. Set it once and the **Users** view populates automatically:

```typescript
ObserveModule.forRoot({
  // ...
  http: {
    getUserId: (req) => req.user?.id ?? 'anonymous',
  },
});
```

The same option exists on `rpc` (receiving the transport id and the `BaseRpcContext`), `grpc` (receiving the call object), `graphql` (receiving the GraphQL context, for operations with no enclosing HTTP request), and `ws` (receiving the gateway message), each reading the transport's own context instead of an HTTP request. Reporting a user identifier is optional: traffic without one still shows up everywhere except the per-user views. The dashboard treats the identifier as an opaque string and never tries to resolve it into a name or an email, so prefer an opaque internal id over anything personally identifying.

##### Tags and custom attributes

`http`, `rpc`, `grpc`, `graphql`, and `jobs` each accept the same two options for attaching your own data to every request they cover:

| Option          | Applies                                                       | Description                                                                                              |
| --------------- | ------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------- |
| `tags`          | The same static `Record<string, string>` to every request     | Sent to Observe. For constants that don't vary per call, e.g., `project`, `env`, `region`.               |
| `setAttributes` | A function of the request/call/job, returning key-value pairs | Kept in your application. For per-call context your code reads later, e.g., a tenant id, a feature flag. |

```typescript
ObserveModule.forRoot({
  // ...
  http: {
    tags: { project: 'cats-app', env: process.env.NODE_ENV ?? 'development' },
    setAttributes: (req) => ({ tenantId: req.headers['x-tenant-id'] }),
  },
  jobs: {
    setAttributes: (job) => ({ queueName: job.queueName, jobName: job.name }),
  },
});
```

`tags` appear as tags on the resulting request or job, and are searchable and visible on its detail page.

`setAttributes` values are **not sent to Observe** and don't appear in the dashboard. As each call starts, they're written to its [request-scoped attributes](/observability/manual-instrumentation#request-scoped-attributes), the same as calling `setAttribute()` for each key yourself, so any code handling that call can read them with `getAttribute()`. The function receives whatever the transport has: the request for `http`, the transport id and `BaseRpcContext` for `rpc`, the call object for `grpc`, the resolve info and GraphQL context for `graphql`, and `{{ '{' }} queueName, name, id {{ '}' }}` for `jobs`.

A key named like `traceIdKey`, or like one of the SDK's own `#`-prefixed keys, is left out with a warning, so a request can't choose its own trace id.

To see a per-call value in the dashboard, add it as a tag on a span with `TracerService` (see [Manual instrumentation](/observability/manual-instrumentation)):

```typescript
const span = await this.tracerService.activeSpan();
span.addTags({ tenantId: String(this.tracerService.getAttribute('tenantId')) });
```

> info **Hint** A GraphQL server is usually an HTTP endpoint, so its requests are already subject to the `http` options: `http.ignore` drops a request before the GraphQL layer sees it, and `http.getUserId` supplies the user for queries over HTTP. The `graphql` block tunes what happens _inside_ a request that was let through, per operation rather than per resolver, and `graphql.getUserId` is only consulted for operations that aren't already inside an HTTP trace, such as subscriptions over a WebSocket.

##### Ignoring noisy operations

Every inbound transport block (`http`, `rpc`, `grpc`, `graphql`, and `ws`) has an `ignore` option that skips instrumentation entirely for matching calls, such as a health check endpoint, an internal probe, or anything else not worth a trace:

```typescript
ObserveModule.forRoot({
  // ...
  http: {
    ignore: ['/health', { method: 'GET', path: /^\/internal\// }],
  },
  rpc: {
    ignore: (transportId, ctx) =>
      ctx instanceof TcpContext && ctx.getPattern() === 'ping',
  },
  grpc: {
    ignore: (call) => call.path.endsWith('/Health/Check'),
  },
  graphql: {
    ignore: (info) => info.fieldName === 'healthcheck',
  },
});
```

`http.ignore` accepts an array of paths, `{{ '{' }} method, path {{ '}' }}` pairs (`path` can be a string or a `RegExp`), and plain `RegExp`s or a single predicate function over the request. `rpc.ignore`, `grpc.ignore`, and `graphql.ignore` are predicates over the transport's own context (the `@nestjs/microservices` transport id and `BaseRpcContext`, the gRPC call object, and the GraphQL resolve info respectively). Matching a GraphQL field name skips the whole operation that field leads, not only that field: an operation is measured end to end, so it is either traced or not.

`ignore` stops telemetry from being generated at all. The dashboard's spend-control drop filters are a different tool: they discard already-generated events at ingestion to reduce billed volume. Use `ignore` when you don't want a trace to exist, and drop filters when you want to tune cost on data the SDK is already producing.

`http` additionally takes `queryParamsObfuscateRegex`, a `RegExp` that masks sensitive query string values before they're sent. It is applied on top of the built-in redaction, which always masks well-known sensitive parameters (`token`, `password`, `code`, `signature`, and so on).

##### Trace sampling and batching

```typescript
ObserveModule.forRoot({
  // ...
  tracesSampleRate: 0.25,
  maxTracesPerBatch: 1000,
  flushInterval: 5000,
});
```

| Option              | Type                                                                       | Default | Description                                                                                               |
| ------------------- | -------------------------------------------------------------------------- | ------- | --------------------------------------------------------------------------------------------------------- |
| `tracesSampleRate`  | `number \| ((protocol: 'http' \| 'rpc' \| 'grpc' \| 'graphql' \| 'ws', attributes) => boolean)` | `1.0`   | Fraction of traces sent, or a predicate for per-trace decisions. `0` counts as unset and sends everything; pass `() => false` to send none. `1.0` sends everything; `0.1` sends 10%. |
| `maxTracesPerBatch` | `number`                                                                   | `1000`  | Caps how many traces go out per batch, to bound volume on high-traffic applications.                      |
| `flushInterval`     | `number` (ms)                                                              | `5000`  | How often the SDK batches and sends collected traces.                                                     |

Telemetry is buffered in the process and shipped on the flush interval rather than inline with each request. Sampling here decides what the SDK _produces_. The dashboard's per-project spend controls (span sampling, rate caps, drop filters) act on what it has already sent, and you can change them without a redeploy.

#### Declaring objectives in code

`@Objective()` states what a route promises next to the handler that has to keep it, and Observe turns each promise into an [SLO](/observability/dashboard#slos). The objective is written, reviewed, and versioned with the route it covers, in the same change:

```typescript
import { Objective } from '@nestjs/observe';

@Controller('orders')
export class OrdersController {
  @Post()
  @Objective({ availability: 99.9, latency: { underMs: 300, target: 99 } })
  create(@Body() dto: CreateOrderDto) {
    return this.ordersService.create(dto);
  }
}
```

| Option         | What it promises                                                                         |
| -------------- | ---------------------------------------------------------------------------------------- |
| `availability` | This percentage of requests don't fail with an unhandled error - `99.9` for three nines. |
| `latency`      | `{{ '{' }} underMs, target {{ '}' }}`: `target` percent of requests finish in under `underMs` milliseconds. |
| `windowDays`   | The rolling window it's judged over: 7, 14, 28 (the default), or 30 days.                |
| `name`         | What the dashboard calls it, instead of the route and the promise.                       |

Targets run from 90 to 99.999, and a handler can carry up to ten `@Objective()`s; anything outside those bounds is logged and left out when the application starts. Each promise becomes its own SLO, scoped to the application and the route the handler serves, and appears once the route has had traffic. From then on the code owns it: change a target, a window, or a name and deploy, and the same SLO moves. The dashboard marks a declared SLO **in code** and doesn't edit it, and deleting it there doesn't last while the decorator is in place, because the SDK restates each route's objectives hourly. To retire one, remove the decorator, then delete the SLO. SLOs need a plan that has them (Scale or Enterprise); on any other plan, declarations are sent and ignored.

#### Full configuration reference

All options at a glance. Options listed under `createObserveModule()` must be set there; everything else goes to `forRoot()`/`forRootAsync()`.

| Where                   | Option                                | Purpose                                                                   |
| ----------------------- | ------------------------------------- | ------------------------------------------------------------------------- |
| `createObserveModule()` | `sourceContext`                       | Attach source lines to error stack frames                                 |
| `createObserveModule()` | `traceIdKey`                          | Context key the trace id is stored under                                  |
| `createObserveModule()` | `traceIdGenerator`                    | How each request obtains its trace id                                     |
| `createObserveModule()` | `attachTraceIdToLogs`                 | Add the trace id to `ConsoleLogger` output                                |
| `createObserveModule()` | `skipInstrumentation`                 | Predicate that excludes provider instances from instrumentation           |
| `forRoot()`             | `appKey`, `appSecret`                 | Project API key pair (or `OBSERVE_APP_KEY`, `OBSERVE_APP_SECRET`)         |
| `forRoot()`             | `endpoint`                            | Collector base URL (or `OBSERVE_ENDPOINT`)                                |
| `forRoot()`             | `enabled`                             | `false` records and sends nothing, for development and CI                 |
| `forRoot()`             | `serviceId`, `serviceVersion`         | Application and release identity (the release is inferred when unset)    |
| `forRoot()`             | `http`, `rpc`, `grpc`, `graphql`      | Per-transport `tags`, `setAttributes`, `getUserId`, `ignore`              |
| `forRoot()`             | `jobs`                                | `tags` and `setAttributes` for queue and scheduled jobs                   |
| `forRoot()`             | `http.queryParamsObfuscateRegex`      | Mask sensitive query string values                                        |
| `forRoot()`             | `http.capture`                        | Headers (and optionally body) recorded for failed and slow requests       |
| `forRoot()`             | `outgoing`                            | Database query and outbound HTTP spans; `outgoing.llm` for model calls   |
| `forRoot()`             | `openTelemetry`                       | W3C `traceparent` in and out, beside an OpenTelemetry SDK                 |
| `forRoot()`             | `otlp`                                | Export spans over OTLP to your OpenTelemetry backend                      |
| `forRoot()`             | `ws`                                  | WebSocket gateway `tags`, `setAttributes`, `getUserId`, `ignore`          |
| `forRoot()`             | `runtimeMetrics`, `runtimeMetricsInterval` | Profiler samples and heartbeat                                       |
| `forRoot()`             | `forwardLogs`, `redaction`            | Logs streaming and scrubbing                                              |
| `forRoot()`             | `tracesSampleRate`                    | Fraction (or predicate) of traces to send                                 |
| `forRoot()`             | `maxTracesPerBatch`, `flushInterval`  | Batching                                                                  |
| `forRoot()`             | `spanCollapse`                        | Collapse repeated sibling spans (default threshold `20`, keep slowest `3`) |
| `forRoot()`             | `shutdownFlushTimeout`                | How long closing the application waits for the final send (default `2000` ms) |
| `forRoot()`             | `debug`                               | SDK diagnostics                                                           |

#### Where to go next

- [Manual instrumentation](/observability/manual-instrumentation) - add your own spans, capture handled errors, attach request-scoped attributes, and report custom metrics.
- [Distributed tracing](/observability/distributed-tracing) - keep one trace across HTTP, gRPC, microservice transports, and GraphQL.
- [Dashboard](/observability/dashboard) - what shows up once the SDK is running, and how the views relate to each other.
